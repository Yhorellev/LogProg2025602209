/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>

int main()
{
    float l,at,pt;
    //asignacion de valores
    l=7;
    at=pow(l,2)*5;
    pt=12*l;
    printf("el area de perimetro total es %f\n",at);
    printf("el perimetro total es %f\n",pt);

    return 0;
}